// Define global variables
let carArray = [];
const makeInput = document.getElementById('make');
const modelInput = document.getElementById('model');
const yearInput = document.getElementById('year');
const colorInput = document.getElementById('color');
const submitButton = document.getElementById('submit');
const displayButton = document.getElementById('display');
const clearButton = document.getElementById('clear');
const countDiv = document.getElementById('count');

// Define function to add a car to the array
function addCar() {
  const car = {
    make: makeInput.value,
    model: modelInput.value,
    year: yearInput.value,
    color: colorInput.value
  };
  carArray.push(car);
  countDiv.innerText = `Total Cars entered: ${carArray.length}`;
  makeInput.value = '';
  modelInput.value = '';
  yearInput.value = '';
  colorInput.value = '';
}

// Define function to display the array of cars in a popup window
function displayCars() {
  let carString = '';
  for (let i = 0; i < carArray.length; i++) {
    carString += `Make: ${carArray[i].make}\nModel: ${carArray[i].model}\nYear: ${carArray[i].year}\nColor: ${carArray[i].color}\n\n`;
  }
  if (carString === '') {
    alert('No Cars entered yet!');
  } else {
    alert(carString);
  }
}

// Attach event listeners to buttons
submitButton.addEventListener('click', function(event) {
  event.preventDefault();
  addCar();
});

displayButton.addEventListener('click', function() {
  displayCars();
});

clearButton.addEventListener('click', function() {
  carArray = [];
  countDiv.innerText = 'Total Cars entered: 0';
});
