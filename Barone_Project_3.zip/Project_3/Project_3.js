// Get elements from the DOM
const form = document.querySelector('form');
const inputOne = document.querySelector('#input-one');
const inputTwo = document.querySelector('#input-two');
const operation = document.querySelector('#operation');
const result = document.querySelector('#result');

// Add event listener to form
form.addEventListener('submit', e => {
  e.preventDefault(); // Prevent form from submitting

  // Get values from form
  const numOne = parseFloat(inputOne.value);
  const numTwo = parseFloat(inputTwo.value);
  const op = operation.value;

  // Perform operation
  let calcResult;
  if (op === '+') {
    calcResult = numOne + numTwo;
  } else if (op === '-') {
    calcResult = numOne - numTwo;
  } else if (op === '*') {
    calcResult = numOne * numTwo;
  } else if (op === '/') {
    calcResult = numOne / numTwo;
  }

  // Display result in popup
  result.textContent = `Result: ${calcResult}`;
  alert(`Result: ${calcResult}`);
});